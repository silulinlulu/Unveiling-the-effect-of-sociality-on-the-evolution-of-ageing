#include "colony.h"
#include <randomnumbers.h>
#include <utils.h>
#include <algorithm>
#include <execution> //-std=c++17, can use erase_if with -std=c++2a


colony::colony(const reproductive& q, const reproductive& k ):
     Q{q},
     K{k}
{
    IWF.reserve(maxW);
    IWM.reserve(maxW);

    im_nymphs_F.reserve(maxW);
    im_nymphs_M.reserve(maxW);
    m_nymphs_F.reserve(maxW);
    m_nymphs_M.reserve(maxW);
}


genotype colony::offspring_genotype(){
    genotype g{Q.gamete(),K.gamete()};
    return g;
}



int colony::n_eggs(){
    double lambda= f+(Fmax-f) / (1.0 + exp(-(l*static_cast<double>(size()))));
    return rpois(lambda);
}

void colony::maturation(){
    for (size_t i=0; i<im_nymphs_F.size(); ) {
        if (im_nymphs_F[i].get_age() == am_n) {
            m_nymphs_F.emplace_back(std::move(im_nymphs_F[i]));
            remove_from_vec(im_nymphs_F,i);
        } else ++i;
    }

    for (size_t i=0; i<im_nymphs_M.size(); ) {
        if (im_nymphs_M[i].get_age() == am_n) {
            m_nymphs_M.emplace_back(std::move(im_nymphs_M[i]));
            remove_from_vec(im_nymphs_M,i);
        } else ++i;
    }

}

void colony::increment_age(){
    Q.increment_age();
    K.increment_age();
    std::for_each(std::execution::par,im_nymphs_F.begin(),im_nymphs_F.end(),[](auto& f){ f.increment_age();});
    std::for_each(std::execution::par,im_nymphs_M.begin(),im_nymphs_M.end(),[](auto& f){ f.increment_age();});
    std::for_each(std::execution::par,IWF.begin(),IWF.end(),[](auto& f){ f.increment_age();});
    std::for_each(std::execution::par,IWM.begin(),IWM.end(),[](auto& f){ f.increment_age();});
    age++;//colony age
}

void colony::thunder(){if (ru()< mC) alive=false; // everytime step, a thunderstorm may hit the colony and whole colony dies.
                      }

void colony::survival(){


    Q.survival();
    K.survival();

    std::for_each(std::execution::par,m_nymphs_F.begin(),m_nymphs_F.end(),[](auto& f){ f.survival();});
    std::erase_if(m_nymphs_F,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,m_nymphs_M.begin(),m_nymphs_M.end(),[](auto& f){ f.survival();});
    std::erase_if(m_nymphs_M,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,im_nymphs_F.begin(),im_nymphs_F.end(),[](auto& f){ f.survival();});
    std::erase_if(im_nymphs_F,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,im_nymphs_M.begin(),im_nymphs_M.end(),[](auto& f){ f.survival();});
    std::erase_if(im_nymphs_M,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,IWF.begin(),IWF.end(),[](auto& f){ f.survival();});
    std::erase_if(IWF,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,IWM.begin(),IWM.end(),[](auto& f){ f.survival();});
    std::erase_if(IWM,[](auto& f){ return !f.is_alive();});


}

//check if alates survive dispersal flight
void colony::survived_flight(){

    std::for_each(std::execution::par,m_nymphs_F.begin(),m_nymphs_F.end(),[](auto& f){ f.survived_flight();});
    std::erase_if(m_nymphs_F,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,m_nymphs_M.begin(),m_nymphs_M.end(),[](auto& f){ f.survived_flight();});
    std::erase_if(m_nymphs_M,[](auto& f){ return !f.is_alive();});
}

//replace the king and queen if needed, only workers





void colony::grow(){

    //only grow if both queen and king are alive
    //lulu: actually not necessary becasue after teh replacement event, there is always a queen and king
    if (Q.is_alive() && K.is_alive()) {

         // step1: produce offspring
            int num_eggs=n_eggs();
            for (int e = 0; e < num_eggs; ++e){
                if (size() < minWorker) {// only produce workers if colony size<20
                if (r2())  IWF.emplace_back(offspring_genotype());  else  IWM.emplace_back(offspring_genotype());
                } else { //produce both workers and nymphs
                if (r2()) {
                    if (ru()<d)  im_nymphs_F.emplace_back(offspring_genotype()); else IWF.emplace_back(offspring_genotype());
                } else {
                    if (ru()<d)  im_nymphs_M.emplace_back(offspring_genotype()); else IWM.emplace_back(offspring_genotype());
                }
            }
    }
    //assuming that all eggs survived, move matured workers to the coresponding vectors
    maturation();
    //they all disperse and don't stay in the nest
    survived_flight();
    //will reproductives (inclu: alates!!) workers stay in the nest survive to next year?
    survival(); //whether individuals can survive to the next year? dead ones removed



    if ((!has_q()) || (!has_k())) alive=false;


    //if colony alive, increment age
    if (is_alive())  increment_age();
    }
}






double colony::sum_im_female_workers()const{
    auto im1{
        std::accumulate(IWF.begin(),IWF.end(),0.0,[](const double& a, const auto& f){ return a + f.get_im(); })
    };
    return im1;
}

double colony::sum_im_male_workers()const{
    auto im1{
        std::accumulate(IWM.begin(),IWM.end(),0.0,[](const double& a, const auto& f){ return a + f.get_im(); })
    };

    return im1;
}

double colony::sum_age_female_workers()const{
    auto a1{
        std::accumulate(IWF.begin(),IWF.end(),0.0,[](const double& a, const auto& f){ return a + f.get_age(); })
    };

    return a1;
}

double colony::sum_age_male_workers()const{
    auto a1{
        std::accumulate(IWM.begin(),IWM.end(),0.0,[](const double& a, const auto& f){ return a + f.get_age(); })
    };


    return a1;
}

int colony::max_age_female_workers() const {
    std::vector<int> vec{0}; 
   for(auto& f:IWF) vec.push_back(f.get_age());
    return *max_element(vec.begin(), vec.end());
}

int colony::max_age_male_workers() const {
    std::vector<int> vec{0};
    for(auto& f:IWM) vec.push_back(f.get_age());
    return *max_element(vec.begin(), vec.end());
}



std::optional<double> colony::neutral_gene_mean_female_worker() const {
    if (IWF.empty()) {
        // Return nothing when there is no female workers
        return std::nullopt;
    } else
    {
//pick a random worker
        auto rw{rn(IWF.size())};
        return IWF[rw].get_relatedness();
    }
}




