#ifndef COLONY_H
#define COLONY_H

#include "parameters.h"
#include "worker.h"
#include "reproductive.h"
#include <vector>
#include <numeric>
#include "randomnumbers.h"
#include <algorithm>
#include <iterator>
#include <random>
#include <optional>




class population;
class colony{
    reproductive Q;
    reproductive K;
    std::vector<worker> IWF; //female immature workers  
    std::vector<worker> IWM; //male immature workers

    std::vector<reproductive> im_nymphs_F; //imature female dispersers
    std::vector<reproductive> im_nymphs_M; //inmature male dispersers
    std::vector<reproductive> m_nymphs_F; //mature female dispersers
    std::vector<reproductive> m_nymphs_M; //mature male dispersers
    bool alive{true};
    int age{0};
    friend class population; //IP: to access the nymphs for moving to population level dispersers

public:
    //constructor
    colony(const reproductive& q, const reproductive& k);

    bool has_q() const { return Q.is_alive();}// is there a queen?
    bool has_k() const { return K.is_alive();}// is there a king?

    genotype offspring_genotype();// queen mates with king, mutation occurs; returns an offspring genotype
    int n_eggs();
    void maturation(); // move matured workers to the corresponding vectors


    void survival(); //update whether individuals can survive to the next year based on intrinsic & extrinsic factors
    void survived_flight(); //whether nymphs survived nutial flightsni
    void replace_reproductives(); //replace reproductives with workers

    void grow();// produce offspring
    void increment_age();//in the end of year, if individual is alive, age+1


 // bunch of getters

    long nr_immature_female_workers() const { return IWF.size(); }
    long nr_immature_male_workers() const { return IWM.size(); }


    long nr_immature_female_nymphs() const { return im_nymphs_F.size(); }
    long nr_immature_male_nymphs() const { return im_nymphs_M.size(); }
    long nr_immature_nymphs() const { return nr_immature_female_nymphs() + nr_immature_male_nymphs(); }
    long nr_mature_female_nymphs() const { return m_nymphs_F.size(); }
    long nr_mature_male_nymphs() const { return m_nymphs_M.size(); }
    long nr_female_nymphs() const { return nr_immature_female_nymphs() + nr_mature_female_nymphs(); }
    long nr_male_nymphs() const { return nr_immature_male_nymphs() + nr_mature_male_nymphs(); }
    double im_Q() const { return Q.get_im(); }
    double im_K() const { return K.get_im(); }
    //long size() const { return nr_female_workers() + nr_female_nymphs() + nr_male_workers() + nr_male_nymphs();}
    long size() const { return nr_immature_female_workers() + nr_immature_male_workers();}


    int get_age_Q() const { return Q.get_age(); }
    int get_age_K() const { return K.get_age(); }
    int get_age_C() const { return age; }

    bool is_alive() const { return alive; }
    void thunder();//colony mortality, if this happens, colony cannot disperse

    //statistics
    double sum_im_female_workers() const;
    double sum_im_male_workers() const;
    double sum_age_female_workers() const;
    double sum_age_male_workers() const;
    int max_age_female_workers() const;
    int max_age_male_workers() const;
    auto get_K() const { return K; }
    auto get_Q() const { return Q; }
    std::optional<double> neutral_gene_mean_female_worker() const;

   //randomly chose an mature worker



};

#endif // COLONY_H
