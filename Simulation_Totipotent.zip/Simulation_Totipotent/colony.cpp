#include "colony.h"
#include <randomnumbers.h>
#include <utils.h>
#include <algorithm>
#include <execution>//-std=c++17



colony::colony(const reproductive& q, const reproductive& k ):
     Q{q},
     K{k}
{
    IWF.reserve(maxW);
    IWM.reserve(maxW);
    MWF.reserve(maxW);
    MWM.reserve(maxW);

}


genotype colony::offspring_genotype(){
    genotype g{Q.gamete(),K.gamete()};
    return g;
}


int colony::n_eggs(){
    double lambda= f+(Fmax-f) / (1 + exp(-(l*static_cast<double>(size()))));
    return rpois(lambda);
}

void colony::maturation(){
    for (size_t i=0; i<IWF.size(); ) {
        if (IWF[i].get_age() == am){
            MWF.emplace_back(std::move(IWF[i]));
            remove_from_vec(IWF,i);
        } else ++i;
    }

    for (size_t i=0; i<IWM.size(); ) {
        if (IWM[i].get_age() == am){
            MWM.emplace_back(std::move(IWM[i]));
            remove_from_vec(IWM,i);
        } else ++i;
    }

}

void colony::increment_age(){
    Q.increment_age();
    K.increment_age();
    std::for_each(std::execution::par,IWF.begin(),IWF.end(),[](auto& f){ f.increment_age();});
    std::for_each(std::execution::par,IWM.begin(),IWM.end(),[](auto& f){ f.increment_age();});
    std::for_each(std::execution::par,MWF.begin(),MWF.end(),[](auto& f){ f.increment_age();});
    std::for_each(std::execution::par,MWM.begin(),MWM.end(),[](auto& f){ f.increment_age();});
    age++;//colony age
}


void colony::survival(){
    Q.survival();
    K.survival();

    std::for_each(std::execution::par,IWF.begin(),IWF.end(),[](auto& f){ f.survival();});
    std::erase_if(IWF,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,IWM.begin(),IWM.end(),[](auto& f){ f.survival();});
    std::erase_if(IWM,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,MWF.begin(),MWF.end(),[](auto& f){ f.survival();});
    std::erase_if(MWF,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,MWM.begin(),MWM.end(),[](auto& f){ f.survival();});
    std::erase_if(MWM,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,dispersers_F.begin(),dispersers_F.end(),[](auto& f){ f.survival();});
    std::erase_if(dispersers_F,[](auto& f){ return !f.is_alive();});

    std::for_each(std::execution::par,dispersers_M.begin(),dispersers_M.end(),[](auto& f){ f.survival();});
    std::erase_if(dispersers_M,[](auto& f){ return !f.is_alive();});
}


void colony::dispersal(){
    for(size_t i=0; i<MWF.size(); ) {
        if (ru() < d){
            // did they survive the flight?
            if (ru() > md) {
                dispersers_F.emplace_back(std::move(MWF[i]));
            }
            remove_from_vec(MWF,i);
        } else ++i;
    }

    for(size_t i=0; i<MWM.size(); ) {
        if (ru() < d){
            // did they survive the flight?
            if (ru() > md) {
                dispersers_M.emplace_back(std::move(MWM[i]));
            }
            remove_from_vec(MWM,i);
        } else ++i;
    }

}



//replace the king and queen if needed
void colony::replace_reproductives(){

    // replace queen if necessary
    if (!has_q()){
        auto rw{rn(MWF.size())};
        Q = std::move(MWF[rw]);
        remove_from_vec(MWF,rw);
    }

    // replace king if necessary
    if (!has_k()){
        auto rw{rn(MWM.size())};
        K = std::move(MWM[rw]);
        remove_from_vec(MWM,rw);
    }
}


void colony::grow(){

    //only grow if both queen and king alive
    if (has_q() && has_k()) {

        //step1: producing female and male eggs, fill female , male worker vectors
        int num_eggs = n_eggs();

        for (int e = 0; e < num_eggs; ++e){
            if(r2()) IWF.emplace_back(offspring_genotype());
            else IWM.emplace_back(offspring_genotype());
        }
    }//end of step 1

    //step2 are workers matured?
    maturation();

    //step3 will matured workers fly away from the nest? random, update isDisperse and become_reproductives
    dispersal();

    //step5 update survival for queen, king and alll workers (inc:dispersers) stayed in the nest
    survival();

    //replace
    if ((!has_q() && MWF.empty()) || (!has_k() && MWM.empty())) alive=false;
    else replace_reproductives(); //neotenics develop if a queen or king die and update colony survival, using non dispersers

    //if colony survived to next year, update workers survival and increment age
    if (alive) increment_age();
}


double colony::sum_im_female_workers()const{
    auto im1{
        std::accumulate(IWF.begin(),IWF.end(),0.0,[](const double& a, const auto& f){ return a + f.get_im(); })
    };

    auto im2{
        std::accumulate(MWF.begin(),MWF.end(),0.0,[](const double& a, const auto& f){ return a + f.get_im(); })
    };

    return im1+im2;
}

double colony::sum_im_male_workers()const{
    auto im1{
        std::accumulate(IWM.begin(),IWM.end(),0.0,[](const double& a, const auto& f){ return a + f.get_im(); })
    };

    auto im2{
        std::accumulate(MWM.begin(),MWM.end(),0.0,[](const double& a, const auto& f){ return a + f.get_im(); })
    };

    return im1+im2;
}

double colony::sum_age_female_workers()const{
    auto a1{
        std::accumulate(IWF.begin(),IWF.end(),0.0,[](const double& a, const auto& f){ return a + f.get_age(); })
    };

    auto a2{
        std::accumulate(MWF.begin(),MWF.end(),0.0,[](const double& a, const auto& f){ return a + f.get_age(); })
    };

    return a1+a2;
}

double colony::sum_age_male_workers()const{
    auto a1{
        std::accumulate(IWM.begin(),IWM.end(),0.0,[](const double& a, const auto& f){ return a + f.get_age(); })
    };

    auto a2{
        std::accumulate(MWM.begin(),MWM.end(),0.0,[](const double& a, const auto& f){ return a + f.get_age(); })
    };

    return a1+a2;
}

int colony::max_age_female_workers() const {
    std::vector<int> vec{0};
    if(MWF.size()>0) for(auto& f:MWF) vec.push_back(f.get_age());
    else for(auto& f:IWF) vec.push_back(f.get_age());
    return *max_element(vec.begin(), vec.end());
}

int colony::max_age_male_workers() const {
    std::vector<int> vec{0};
    if(MWM.size()>0) for(auto& f:MWM) vec.push_back(f.get_age());
    else for(auto& f:IWM) vec.push_back(f.get_age());
    return *max_element(vec.begin(), vec.end());
}

std::optional<double> colony::neutral_gene_mean_female_worker() const {
    if (IWF.empty()) {
        // Return nothing when there is no female workers
        return std::nullopt;
    } else
    {
//pick the first worker
        auto rw{rn(IWF.size())};
        return IWF[rw].get_relatedness();
    }
}



void colony::thunder(){if (ru()< mC) alive=false; // everytime step, a thunderstorm may hit the colony and whole colony dies.
                      }

