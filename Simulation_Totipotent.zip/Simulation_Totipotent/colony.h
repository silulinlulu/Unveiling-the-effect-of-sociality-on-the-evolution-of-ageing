#ifndef COLONY_H
#define COLONY_H

#include "parameters.h"
#include "worker.h"
#include "reproductive.h"
#include <vector>
#include <numeric>
#include <optional>

class population;
class colony{
    reproductive Q;
    reproductive K;
    std::vector<worker> IWF; // female immature workers
    std::vector<worker> IWM; // male immature workers
    std::vector<worker> MWF; // female mature workers
    std::vector<worker> MWM; // male mature workers
    std::vector<reproductive> dispersers_F;
    std::vector<reproductive> dispersers_M;
    bool alive{true};
    int age{0};
    friend class population;

public:
    //constructor
    colony(const reproductive& q, const reproductive& k);

    bool has_q() const { return Q.is_alive();}// is there a queen?
    bool has_k() const { return K.is_alive();}// is there a king?

    genotype offspring_genotype();// queen mates with king, mution occurs; returns an offspring genotype
    int n_eggs();
    void maturation(); // move matured workers to the corresponding vectors


    void survival(); //update whether individuals can survive to the next year based on inrincic extrinsic factors
    void dispersal();
    void replace_reproductives(); //replace reproductives with workers

    void grow();// produce offspring
    void increment_age();//in the end of year, if individual is alive, age+1


 // bunch of getters

    long nr_immature_female_workers() const { return IWF.size(); }
    long nr_immature_male_workers() const { return IWM.size(); }
    long nr_mature_female_workers() const { return MWF.size(); }
    long nr_mature_male_workers() const { return MWM.size(); }
    long nr_female_workers() const { return nr_immature_female_workers() + nr_mature_female_workers(); }
    long nr_male_workers() const { return nr_immature_male_workers() + nr_mature_male_workers(); }

    double im_Q() const { return Q.get_im(); }
    double im_K() const { return K.get_im(); }

    long size() const { return nr_female_workers() + nr_male_workers();}

    int get_age_Q() const { return Q.get_age(); }
    int get_age_K() const { return K.get_age(); }
    int get_age_C() const { return age; }


    bool is_alive() const { return alive; }


    //statistics
    double sum_im_female_workers() const;
    double sum_im_male_workers() const;
    double sum_age_female_workers() const;
    double sum_age_male_workers() const;
    int max_age_female_workers() const;
    int max_age_male_workers() const;
    auto get_K() const { return K; }
    auto get_Q() const { return Q; }
    std::optional<double> neutral_gene_mean_female_worker() const;
     void thunder();

};

#endif // COLONY_H






