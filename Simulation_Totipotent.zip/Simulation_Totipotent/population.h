#ifndef POPULATION_H
#define POPULATION_H

#include "colony.h"
#include "parameters.h"
#include <iostream>
#include <fstream>
#include <sstream>
using std::ofstream;
using namespace std;

class population{
private:
    std::vector<colony> pop;
    std::vector<reproductive> female_dispersers;
    std::vector<reproductive> male_dispersers;
    //collection of dispersers regardless of position-biased selection

public:
    //the only constructor
    population(const colony& c);

    double get_size() const;


    void grow();//grow colonies and add new colonies

    void rm_dead_colonies();
    void increment_age();

    void write_stats(std::ofstream& file, int& gen)const;
    void write_pop_queen(std::ofstream& file, int& gen)const;
    void write_pop_king(std::ofstream& file,int& gen)const;
    void write_pop_female(std::ofstream& file, int& gen)const;
    void write_pop_male(std::ofstream& file, int& gen)const;
    void write_pop_relatedness(std::ofstream& file, int& gen)const;
};


#endif // POPULATION_H
