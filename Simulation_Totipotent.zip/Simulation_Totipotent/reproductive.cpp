#include <reproductive.h>
#include "randomnumbers.h"
#include "utils.h"


reproductive::reproductive(const genotype& G)
    : g{G}
{}

reproductive::reproductive(const worker& w)
    :age{w.get_age()}
    ,g{w.get_genome()}
{ }

double reproductive::get_im() const {
    auto index{ Ω+age };
    return 1.0-logist(0.5*(g[0][index]+g[1][index]));
}

void reproductive::survival() {
    if (age < amax){
        auto im{ get_im() };
        if(ru() < im + (1-im)*mr) alive=false;
    }
    else alive=false;
    }



haplotype reproductive::gamete() {
    const bool l=r2();
    haplotype h=Eigen::Map<haplotype, Eigen::Unaligned>(g[l].data(), g[l].size());
    for (long i=0, hs=h.size(); i<hs; ++i) if (ru()<µ) h[i]+=rnorm(σ, b);
    return h;
}

haplotype reproductive::get_phenotype() const {
    return 0.5*(g[0]+g[1]);
}
