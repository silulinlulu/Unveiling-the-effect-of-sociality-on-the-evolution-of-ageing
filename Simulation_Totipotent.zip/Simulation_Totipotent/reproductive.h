#ifndef REPRODUCTIVE_H
#define REPRODUCTIVE_H

#include "parameters.h"
#include "worker.h"


class reproductive{
    int age{am};
    bool alive{true};
    genotype g{primary_gene};

public:
    reproductive()=default;

    //alates constructed from zgotes
    reproductive(const genotype& G);

    //neotenic reproductives constructed from matured workers
    reproductive(const worker& w);


    void survival();
    void increment_age() { age++; };

    haplotype gamete();


    int get_age() const { return age; }
    double get_im() const;
    bool is_alive() const { return alive; }
    haplotype get_phenotype() const;
    double get_relatedness() const {
        size_t n = get_phenotype().size();
        return get_phenotype()[n-1];
    }//the last gene is the relatedness gene
};



#endif // REPRODUCTIVE_H

