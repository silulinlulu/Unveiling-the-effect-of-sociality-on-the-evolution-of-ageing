#include <worker.h>
#include "randomnumbers.h"
#include "utils.h"




void worker::survival() {
    if (age < amax){
        auto im{ get_im() };
        if(ru() < im + (1-im)*mw) alive=false;
    }
    else alive=false;
    }


void worker::increment_age(){
     age++;
}

double worker::get_im() const {
    return 1.0 -logist(0.5*(g[0][age]+g[1][age]));
}

haplotype worker::get_phenotype() const {
     return 0.5*(g[0]+g[1]);
}
