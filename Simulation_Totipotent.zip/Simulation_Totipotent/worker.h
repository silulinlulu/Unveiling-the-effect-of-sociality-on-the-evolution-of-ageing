#ifndef WORKER_H
#define WORKER_H

#include "parameters.h"

class worker{
    int age{0};
    bool alive{true};
    genotype g{primary_gene};

public:
    worker()=default;
    worker(const  genotype& g) : g{g} {} //born during reproduction

    void survival();// determines whether survives or not (sets isAlive)
    void increment_age();// increments age

    int get_age() const { return age; }
    bool is_alive() const { return alive; }
    double get_im() const;
    haplotype get_phenotype() const;
    genotype get_genome() const { return g;}
    double get_relatedness() const {
        size_t n = get_phenotype().size();
        return get_phenotype()[n-1];
    }//the last gene is the relatedness gene
};



#endif // WORKER_H

