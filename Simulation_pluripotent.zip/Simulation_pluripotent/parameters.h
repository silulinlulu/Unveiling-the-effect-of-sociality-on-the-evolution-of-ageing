#ifndef PARAMETERS_H
#define PARAMETERS_H

#include "utils.h"
#include <Eigen/Eigenvalues>
#include <array>
#include <vector>

/*============================set parameters============================*/

/*============================= individuals ================*/

/*============initialization============*/
constexpr static int C=2; // number of castes: reproductives and workers
constexpr static int Ω=20; //number of age classes
constexpr static int amax = 19; //max age an individual can get
constexpr static int p =2; //all individuals are diploid
constexpr static double Xstart = 3.2;//initial survival value at all ages, logist(3.2)=0.96
static std::vector<double> a_r(C*Ω+1,Xstart);//+1, the plus one added a neutral gene in the worker and reproductive genomes
using haplotype=Eigen::VectorXd;
using genotype=std::array<haplotype,p>;
const haplotype v_r = Eigen::Map<haplotype, Eigen::Unaligned>(a_r.data(), a_r.size());
const genotype primary_gene{v_r,v_r};

/*============mutation============*/
constexpr static double µ = 0.01; //mutation rate per gene per generation, normal distribution
constexpr static double b = -0.2; //harm of mutation on survival per mutant
constexpr static double σ = 0.4;//standard deviation of mutation

/*============reproduction============*/
constexpr static double f = 20; //initial fecundity without workers
constexpr static double Fmax=80;//max number of eggs that queen can lay per time step, intotal 50
constexpr static double l=0.2;//slope of fitness benefit by workers
constexpr static double mr = 0.0; //extrinsic mortality{0.0,1} for reproductives.


constexpr static int minWorker = 20;//minimum number of workers required to produce alates
constexpr static double mw = 0.1; //worker extrinsic mortality
/*============maturation============*/
constexpr static int am_w = 1; //age when workers can become neotenic
constexpr static int am_n = 1; //age when nymphs can fly

/*============dispersal============*/
constexpr static double d=0.1;// probability that a newborn is a disperser
constexpr static double md = 0.8;//probability of dying during flight

/*===========================colony========================*/
constexpr static int Nstart = 1000; //number of colonies at the beginning;
constexpr static int Nmax=1000; // max number of colonies allowed in the population
constexpr static int maxW=200; // number of spaces reserved for worker vector

constexpr static double mC = 0.001; //extrinsic mortality at colony level

/*==========================generations====================*/
constexpr static int t = 100000; //number of timesteps to run
constexpr static int skip_evol = 1000; //print evolution history every 500 time step

#endif // PARAMETERS_H
