#include <worker.h>
#include "randomnumbers.h"
#include "utils.h"



void worker::survival(){
    if (age<amax){ //IP: changes get_age() to age
        auto im{get_im()}; //IP: added this
        if (ru()<im+(1.0-im)*mw) alive=false;
    }
    else alive=false;
    }

double worker::get_im() const {
    return 1.0 -logist(0.5*(g[0][age]+g[1][age]));
}

haplotype worker::get_phenotype() const {
     return 0.5*(g[0]+g[1]);
}

