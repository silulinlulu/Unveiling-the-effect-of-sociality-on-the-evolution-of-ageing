#include "population.h"
#include <algorithm>
#include "randomnumbers.h"
#include <vector>
#include <execution> //parallize, faster
#include <iostream>
#include <Eigen/Eigenvalues>


population::population(const colony&c){//population constructor
    //reserve space in the vector;
    pop.reserve(Nmax);
    for(int i=0; i<Nstart; i++){
        pop.push_back(c);
    }
    female_dispersers.reserve(maxW); //IP: why maxW? There could be more.
    male_dispersers.reserve(maxW);
}

double population::get_size() const {return static_cast<double>(pop.size());}
//IP: why double? can cast to double where needed.

void population::rm_dead_colonies(){ pop.erase(std::remove_if(pop.begin(),pop.end(),[](colony& c){ return !c.is_alive(); }),pop.end());}
//IP: can use erase_if instead.

void population::grow(){

    female_dispersers.clear();
    male_dispersers.clear();
    std::for_each(std::execution::par,pop.begin(),pop.end(),[](auto& f){ f.thunder();}); //thunder hit before the colony can disperse.
    rm_dead_colonies();


    std::for_each(std::execution::par,pop.begin(),pop.end(),[](auto& f){ f.grow();});
    //IP: at the colony level there is also paralellization. I wonder how that works out,
    // paralellization within paralelliztion.

    //move all dispersers (mature nymphs) into population
    for (auto& c:pop){
        female_dispersers.insert(female_dispersers.end(),std::make_move_iterator(c.m_nymphs_F.begin()),
                                 std::make_move_iterator(c.m_nymphs_F.end()));
        c.m_nymphs_F.clear();

        male_dispersers.insert(male_dispersers.end(),std::make_move_iterator(c.m_nymphs_M.begin()),
                                 std::make_move_iterator(c.m_nymphs_M.end()));
        c.m_nymphs_M.clear();
    }

    rm_dead_colonies();

    // first shuffle the disperser vectors
    std::random_shuffle ( female_dispersers.begin(), female_dispersers.end() );
    std::random_shuffle ( male_dispersers.begin(), male_dispersers.end() );

    while(!female_dispersers.empty() && !male_dispersers.empty() && pop.size()<Nmax){
        pop.emplace_back(std::move(female_dispersers.back()),std::move(male_dispersers.back()));//add one new colony to population
        female_dispersers.pop_back();
        male_dispersers.pop_back();
    }



}//end of population::grow()


void population::write_stats(std::ofstream& file, int& gen)const { 

    double im_Q{0.0};
    double im_K{0.0};
    double sum_im_FW{0.0};
    double sum_im_MW{0.0};
    long age_Q{0};
    long age_K{0};
    long age_C{0};
    double sum_age_FW{0.0};
    double sum_age_MW{0.0};
    long nr_FW{0};
    long nr_MW{0};


    vector<int> max_ages_FW;
    vector<int> max_ages_MW;
    vector<int> ages_Q;
    vector<int> ages_K;
    vector<int> ages_colony;




    for (auto& c : pop){
        im_Q += c.im_Q();
        im_K += c.im_K();
        sum_im_FW += c.sum_im_female_workers();
        sum_im_MW += c.sum_im_male_workers();
        age_Q += c.get_age_Q();
        age_K += c.get_age_K();
        age_C += c.get_age_C();
        sum_age_FW += c.sum_age_female_workers();
        sum_age_MW += c.sum_age_male_workers();
        nr_FW += c.nr_female_workers();
        nr_MW += c.nr_male_workers();
        max_ages_FW.push_back(c.max_age_female_workers());
        max_ages_MW.push_back(c.max_age_male_workers());
        ages_Q.push_back(c.get_age_Q());
        ages_K.push_back(c.get_age_K());
        ages_colony.push_back(c.get_age_C());

    }

    ostreamFork osf(file, std::cout); // write same stuff to file and screen

    double d_popsize{static_cast<double>(pop.size())};
    osf << std::setw(10) << gen;//timestep
    osf << std::setw(15) << std::setprecision(5);
    osf << std::setw(10) << d_popsize;//number of colonies

    osf << std::setw(20) << im_Q/d_popsize;//mean queen intrinsic mortality
    osf << std::setw(20) << im_K/d_popsize;//mean king intrinsic mortality
    osf << std::setw(20) << sum_im_FW/static_cast<double>(nr_FW);//mean female intrinsic mortality
    osf << std::setw(20) << sum_im_MW/static_cast<double>(nr_MW);//mean male intrinsic mortality

    osf << std::setw(10) << static_cast<double>(age_Q)/d_popsize;//mean q age
    osf << std::setw(10) << static_cast<double>(age_K)/d_popsize;//mean king age
    osf << std::setw(10) << static_cast<double>(age_C)/d_popsize;//mean colony age
    osf << std::setw(10) << sum_age_FW/static_cast<double>(nr_FW);//mean female worker age
    osf << std::setw(10) << sum_age_MW/static_cast<double>(nr_MW);//mean male worker age
    osf << std::setw(10) << static_cast<double>(nr_FW)/d_popsize;//mean nr female workers
    osf << std::setw(10) << static_cast<double>(nr_FW)/d_popsize;//mean nr male workers

    osf << std::setw(10) << std::accumulate(max_ages_FW.begin(), max_ages_FW.end(), 0.0)/static_cast<double>(max_ages_FW.size());//mean of max female age across all colonies
    osf << std::setw(10) << std::accumulate(max_ages_MW.begin(), max_ages_MW.end(), 0.0)/static_cast<double>(max_ages_MW.size());//mean of max male age across all colonies

    osf << std::setw(10) << *max_element(max_ages_FW.begin(), max_ages_FW.end());//max female worker age
    osf << std::setw(10) << *max_element(max_ages_MW.begin(), max_ages_MW.end());//max male worker age
    osf << std::setw(10) << *max_element(ages_Q.begin(), ages_Q.end());//max queen age
    osf << std::setw(10) << *max_element(ages_K.begin(), ages_K.end());//max king age
    osf << std::setw(10) << *max_element(ages_colony.begin(), ages_colony.end());//max colony age



    osf << std::endl;
}

void population::write_pop_female(std::ofstream& file, int& gen) const{//the rest calculate in R, first get the mean of all individuals
   for (auto& col : pop){//at the last time step
        for(auto& f : col.IWF){
            haplotype p{f.get_phenotype()};
        for (Eigen::Index i=0; i<p.size(); ++i)
            file << std::setw(15) << std::setprecision(5) << p[i];
        file << std::setw(10) << gen;
        file << std::endl;
        }

        for(auto& f : col.MWF){
            haplotype p{f.get_phenotype()};
        for (Eigen::Index i=0; i<p.size(); ++i)
            file << std::setw(15) << std::setprecision(5) << p[i];
        file << std::setw(10) << gen;
        file << std::endl;
        }

    }

}

void population::write_pop_male(std::ofstream& file, int& gen) const{
    for (auto& col : pop){//at the last time step
         for(auto& f : col.IWM){
             haplotype p{f.get_phenotype()};
         for (Eigen::Index i=0; i<p.size(); ++i)
             file << std::setw(15) << std::setprecision(5) << p[i];
         }
         for(auto& f : col.MWM){
             haplotype p{f.get_phenotype()};
         for (Eigen::Index i=0; i<p.size(); ++i)
             file << std::setw(15) << std::setprecision(5) << p[i];
         }
         file << std::setw(10) << gen;
         file << std::endl;
     }

}


void population::write_pop_king(std::ofstream& file, int& gen) const{

    for (auto& col : pop){
        auto p{col.get_K().get_phenotype()};
        for (Eigen::Index i=0; i<p.size(); ++i)
            file << std::setw(15) << std::setprecision(5) << p[i];
        file << std::setw(10) << gen;
        file << std::endl;
    }
}

void population::write_pop_queen(std::ofstream& file, int& gen) const {


    for (auto& col : pop){

    auto p{col.get_Q().get_phenotype()};
        for (Eigen::Index i=0; i<p.size(); ++i)
            file << std::setw(15) << std::setprecision(5) << p[i];
        file << std::setw(10) << gen;
        file << std::endl;
 }
}

void population::write_pop_relatedness(std::ofstream& file, int& gen) const {
    for (const auto& col : pop){
        std::optional<double> mean = col.neutral_gene_mean_female_worker();
        if (mean.has_value()) {
            file << std::setw(15) << mean.value();
        } else {
            file << std::setw(15) << "NA"; // or any other indicator for "not available"
        }

       file << std::setw(15) << col.get_Q().get_relatedness();
       file << std::setw(15) << gen;
       file << std::endl;
 }

}




