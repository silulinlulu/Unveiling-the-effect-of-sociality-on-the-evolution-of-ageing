#ifndef WORKER_H
#define WORKER_H

#include "parameters.h"

class worker{
    int age{0};
    bool alive{true};
    genotype g{primary_gene}; // std::array<haplotype,ploidy>;
    // NB: first half codes for worker phenotype, 2nd half for reproductive

public:
    worker()=default; //IP: for initial population I suppose
    worker(const  genotype& g) : g{g} {} //born during reproduction

    void survival();// determines whether survives or not (sets isAlive)
    void increment_age() { ++ age; }; //IP: moved code here from .cpp

    int get_age() const { return age; }
    bool is_alive() const { return alive; }
    double get_im() const; //IP: intrinsic mortality probability
    haplotype get_phenotype() const; //IP: average of the two sets of genes (logit scale)
    genotype get_genome() const { return g;}
    double get_relatedness() const {
        size_t n = get_phenotype().size();
        return get_phenotype()[n-1];
    }//the last gene is the relatedness gene
};



#endif // WORKER_H
