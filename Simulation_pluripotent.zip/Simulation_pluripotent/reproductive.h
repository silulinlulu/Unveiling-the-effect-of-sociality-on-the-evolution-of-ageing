#ifndef REPRODUCTIVE_H
#define REPRODUCTIVE_H

#include "parameters.h"
#include "worker.h"


class reproductive{
    int age{0};
    bool alive{true};
    genotype g{primary_gene};

public:
    reproductive()=default;

    //alates constructed from zgotes
    reproductive(const genotype& g);

    //neotenic reproductives constructed from matured workers
    reproductive(const worker& w);


    void survival(); //IP based on intrinsic survival alone
    void survived_flight();
    void increment_age() { age++; };

    haplotype gamete(); //IP: includes mutation


    int get_age() const { return age; }
    double get_relatedness() const {
        size_t n = get_phenotype().size();
        return get_phenotype()[n-1];
    }//the last gene is the relatedness gene
    double get_im() const; //IP: probability scale
    bool is_alive() const { return alive; }
    haplotype get_phenotype() const; //IP at logit scale
};



#endif // REPRODUCTIVE_H
