#include <iostream>
#include <chrono>
#include "population.h"
#include "parameters.h"
#include <fstream>
#include "randomnumbers.h"
#include <string>
using std::ofstream;
using namespace std;


int main(int argc, char *argv[]) {
    //int main() {
    auto start = std::chrono::high_resolution_clock::now();

        randomize();
        ofstream ef;
        ofstream qf;
        ofstream rf;
        string  arg1(argv[1]);
        string file1="Q_mr0_mw0.1_mc0.001.txt";
        string file1New= arg1 + file1 ;
        string file2="evol_mr0_mw0.1_mc0.001.txt";
        string file2New = arg1 + file2;
        string file3="relatedness_mr0_mw0.1_mc0.001.txt";
        string file3New = arg1 + file3;

        qf.open(file1New, std::ios_base::app);
        ef.open(file2New, std::ios_base::app);
        rf.open(file3New, std::ios_base::app);


//        ofstream qf{"Q.txt"};
//        ofstream ef("evol.txt");
//        ofstream relatedness("relatedness.txt");

        const reproductive PQ{};//colonies initially founded by primary queens
        const reproductive PK{};
        const colony PC{PQ,PK};
        population P{PC};//using the population constructor, // all colonies have identical queens and kings now
        int END=t-1;
        int Beginning=0;
        P.write_stats(ef,Beginning);

       //P.write_pop_relatedness(relatedness,Beginning);// at beginning, some colonies do not have workers
        for (int i = 0; i < t; ++i){
            //start with queen and king only, at the begining, everything is alive
            P.grow();//increase colony size and population size
            if (i % skip_evol == 0){
                P.write_stats(ef,i);
            }
//            if (i % skip_evol == 0) {
//                P.write_pop_relatedness(relatedness, i);
//            }
        }

        //write the last time step tend-1
        P.write_stats(ef,END);
        P.write_pop_relatedness(rf,END);
        P.write_pop_queen(qf, END);

        auto end = std::chrono::high_resolution_clock::now();
        auto diff = end - start;

        cout << " That took " << std::chrono::duration<double>(diff).count() << " seconds" <<  endl;
        return 0;
}

